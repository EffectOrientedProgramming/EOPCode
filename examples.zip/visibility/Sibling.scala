package visibility

class Sibling {
  val v: Visibility = Visibility()
}
