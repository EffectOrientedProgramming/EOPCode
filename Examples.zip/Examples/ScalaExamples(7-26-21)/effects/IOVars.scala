package effects

object IOVars {
// If the code is taking input from a non-local
  // source, or using input/output, it is
  // considered
  // an effect.

}
