Monads are a mechanism for sequential operations
