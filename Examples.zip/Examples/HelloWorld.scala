object HelloWorldEx {

  @main def helloWorld =
    println("Hello, World!")
}
